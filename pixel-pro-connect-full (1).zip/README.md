# Pixel Pro Connect

A modern SaaS dashboard using Next.js, Firebase, and OpenAI.